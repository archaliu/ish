import { findElement } from "./helpers.js";
import { products1 as products } from "./html.js";

let products1 =
  products.length > 0
    ? products
    : JSON.parse(localStorage.getItem("products1"));
const elWrapperProducts = findElement(".arzon__big-div");
const elProductTemplate = findElement("#template");

function renderProducts(list = products1, parent = elWrapperProducts) {
  parent.textContent = null;

  list.forEach((product) => {
    const newTemplate = elProductTemplate.content.cloneNode(true);
    const elTopImg = findElement(".mahsulot", newTemplate);
    const elTitle = findElement(".tanlov", newTemplate);
    const elPrice = findElement(".yulov", newTemplate);
    const elRealPrice = findElement(".anarxi", newTemplate);
    const elDiccountPrice = findElement(".sikidga", newTemplate);
    const elFavoritBtn = findElement(".btn-yurak", newTemplate);
    const elShopBtn = findElement(".shop-btn", newTemplate);

    if (product.isLiked) {
      elFavoritBtn.src = "imgs/liked.svg";
    }

    elFavoritBtn.dataset.id = product.id;
    elShopBtn.dataset.id = product.id;
    elTopImg.src = product.img;
    elTitle.textContent = product.title;
    elPrice.textContent = product.monthly_payment;
    elRealPrice.textContent = product.real_price;
    elDiccountPrice.textContent = product.discount_price;

    parent.appendChild(newTemplate);
  });
}

renderProducts(products1.filter((product) => product.isLiked === true));
elWrapperProducts.addEventListener("click", (evt) => {
  if (evt.target.className.includes("btn-yurak")) {
    const id = Number(evt.target.dataset.id);

    let products = products1.filter((product) => {
      if (product.id === id) {
        product.isLiked = !product.isLiked;
      }
      return product.isLiked === true;
    });
    console.log();

    localStorage.setItem("products1", JSON.stringify(products1));
    renderProducts(products);
  }
});
