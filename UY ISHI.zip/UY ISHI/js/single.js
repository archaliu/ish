import { findElement } from "./helpers.js";

const elTitle = findElement("#title");
const img = findElement(".product-img");
const elPrice = document.querySelector(".price");
const elInfo = document.querySelector(".info");

let params = new URLSearchParams(document.location.search);
let id = params.get("id");
fetch("https://fakestoreapi.com/products/" + id)
  .then((res) => res.json())
  .then((json) => {
    console.log(json);
    img.src = json.image;
    elTitle.textContent = json.title;
    elPrice.textContent = json.price;
    elInfo.textContent = json.description.slice(0, 144);
  });
