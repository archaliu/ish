import { findElement } from "./helpers.js";
import { products1 as products } from "./html.js";

let products1 =
  products.length > 0
    ? products
    : JSON.parse(localStorage.getItem("products1"));
const elWrapperProducts = findElement(".arzon__big-div");
const elProductTemplate = findElement("#template");
const elFormAdd = findElement("#form-add");
const elFormEdit = findElement("#form-edit");
const elAddBtn = findElement("#add-btn");
const elEditBtn = findElement("#edit-btn");
const elEditImg = findElement("#edit-img");
function renderProducts(list = products1, parent = elWrapperProducts) {
  parent.textContent = null;

  list.forEach((product) => {
    const newTemplate = elProductTemplate.content.cloneNode(true);
    const elTopImg = findElement(".mahsulot", newTemplate);
    const elTitle = findElement(".tanlov", newTemplate);
    const elPrice = findElement(".yulov", newTemplate);
    const elRealPrice = findElement(".anarxi", newTemplate);
    const elDiccountPrice = findElement(".sikidga", newTemplate);
    const elFavoritBtn = findElement(".btn-yurak", newTemplate);
    const elShopBtn = findElement(".shop-btn", newTemplate);
    const elEditBtn = findElement(".btn-info", newTemplate);
    const elDeleteBtn = findElement(".btn-danger", newTemplate);

    elEditBtn.dataset.id = product.id;
    elDeleteBtn.dataset.id = product.id;
    if (product.isLiked) {
      elFavoritBtn.src = "imgs/liked.svg";
    }

    elFavoritBtn.dataset.id = product.id;
    elShopBtn.dataset.id = product.id;
    elTopImg.src = product.img;
    elTitle.textContent = product.title;
    elPrice.textContent = product.monthly_payment;
    elRealPrice.textContent = product.real_price;
    elDiccountPrice.textContent = product.discount_price;

    parent.appendChild(newTemplate);
  });
}

renderProducts();
let imageSrc = "";
var loadFile = function (event) {
  var image = document.getElementById("output");
  image.src = URL.createObjectURL(event.target.files[0]);
  imageSrc = image.src;
};
document.getElementById("file").addEventListener("change", loadFile);

elAddBtn.addEventListener("click", () => {
  const newProduct = {
    id: products1.length > 0 ? products1[products1.length - 1].id + 1 : 1,
    title: elFormAdd.title.value,
    img: imageSrc,
    real_price: elFormAdd.real_price.value,
    discount_price: elFormAdd.discount_price.value,
    monthly_payment: elFormAdd.monthly.value,
    isLiked: false,
    reting: "4",
  };

  products1.push(newProduct);

  localStorage.setItem("products1", JSON.stringify(products1));
  renderProducts();
});

elWrapperProducts.addEventListener("click", (evt) => {
  if (evt.target.className.includes("btn-yurak")) {
    const id = Number(evt.target.dataset.id);

    products1.forEach((product) => {
      if (product.id === id) {
        product.isLiked = !product.isLiked;
      }
    });

    localStorage.setItem("products1", JSON.stringify(products1));
    renderProducts();
  }

  if (evt.target.className.includes("btn-danger")) {
    const id = Number(evt.target.dataset.id);

    const filteredProducts = products1.filter((product) => product.id !== id);
    products1 = filteredProducts;
    localStorage.setItem("products1", JSON.stringify(products1));

    renderProducts();
  }

  if (evt.target.className.includes("btn-info")) {
    const id = Number(evt.target.dataset.id);

    const product = products1.filter((product) => product.id === id)[0];

    elEditImg.src = product.img;
    elFormEdit.title.value = product.title;
    elFormEdit.img.value = product.img;
    elFormEdit.real_price.value = product.real_price;
    elFormEdit.discount_price.value = product.discount_price;
    elFormEdit.monthly.value = product.monthly_payment;

    elEditBtn.addEventListener("click", (evt) => {
      products1.forEach((product) => {
        if (product.id === id) {
          product.title = elFormEdit.title.value;
          product.img = elFormEdit.img.value;
          product.real_price = elFormEdit.real_price.value;
          product.discount_price = elFormEdit.discount_price.value;
          product.monthly_payment = elFormEdit.monthly.value;
        }
      });

      localStorage.setItem("products1", JSON.stringify(products1));
      renderProducts();
    });
  }
});
