import { findElement } from "./helpers.js";
import { products1 } from "./html.js";

const elWrapperProducts = findElement(".arzon__big-div");

const elProductTemplate = findElement("#template");
const add10 = findElement("#add10");
let limit = 10;

add10.addEventListener("click", () => {
  elLoader.style.display = "block";
  add10.style.display = "none";
  limit += 10;
  getDatas();
});
const elSelect = findElement("#select");

const elLoader = findElement(".lds-roller");
function getDatas() {
  fetch(`https://fakestoreapi.com/products?limit=${limit}`)
    .then((res) => res.json())
    .then((json) => {
      elLoader.style.display = "none";
      renderProducts(json);
    });
}
getDatas();

export function renderProducts(list = products1, parent = elWrapperProducts) {
  parent.textContent = null;

  list.forEach((product) => {
    const newTemplate = elProductTemplate.content.cloneNode(true);
    const elTopImg = findElement(".mahsulot", newTemplate);
    const elTitle = findElement(".tanlov", newTemplate);
    const elPrice = findElement(".yulov", newTemplate);
    const elDiccountPrice = findElement(".sikidga", newTemplate);
    const elFavoritBtn = findElement(".btn-yurak", newTemplate);
    const elShopBtn = findElement(".shop-btn", newTemplate);
    if (product.isLiked) {
      elFavoritBtn.src = "imgs/liked.svg";
    }

    elFavoritBtn.dataset.id = product.id;
    elShopBtn.dataset.id = product.id;
    elTopImg.src = product.image;
    elTopImg.dataset.id = product.id;
    elTitle.textContent = product.title;
    elPrice.textContent = product.category;

    elDiccountPrice.textContent = product.price;

    parent.appendChild(newTemplate);
  });
}

elSelect.addEventListener("click", () => {
  elLoader.style.display = "block";
  fetch(`https://fakestoreapi.com/products?sort=${elSelect.value}`)
    .then((res) => res.json())
    .then((json) => {
      elLoader.style.display = "none";
      renderProducts(json);
    });
});

const elCategory = findElement("#categories");
fetch("https://fakestoreapi.com/products/categories")
  .then((res) => res.json())
  .then((categories) => {
    elCategory.textContent = null;
    categories.forEach((category) => {
      const newP = document.createElement("p");
      newP.className = "big-p";
      newP.textContent = category;
      elCategory.appendChild(newP);
    });
  });
elCategory.addEventListener("click", (e) => {
  elLoader.style.display = "block";

  // e.target.classList.toggle("active-category");
  fetch(`https://fakestoreapi.com/products/category/${e.target.textContent}`)
    .then((res) => res.json())
    .then((json) => {
      elLoader.style.display = "none";
      renderProducts(json);
    });
});

const admingakirish = document.querySelector("#adminuchun");
const loginpg = document.querySelector(".none");
const adminpg = document.querySelector(".asosiykirish");
const inputlogin = document.querySelector("#inputlogin");
const inputpassword = document.querySelector("#inputpassword");
admingakirish.addEventListener("click", () => {
  loginpg.className = "position";
});
const admon = function () {
  fetch("https://fakestoreapi.com/auth/login", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      username: inputlogin.value,
      password: inputpassword.value,
    }),
  })
    .then((res) => res.json())
    .then((json) => {
      if (json.token != json.token) {
        alert("KODI NOTOGRI CONSOLDAN TEKSHIRING");
      }
      window.location.replace("./admin.html");
    });
};

adminpg.addEventListener("click", (e) => {
  e.preventDefault();
  admon();
});
console.log(`login:              mor_2314           parol:       83r5^_`);

// let imageSrc = "";
// var loadFile = function (event) {
//   var image = document.getElementById("output");
//   image.src = URL.createObjectURL(event.target.files[0]);
//   imageSrc = image.src;
// };
// document.getElementById("file").addEventListener("change", loadFile);

// elAddBtn.addEventListener("click", () => {
//   const newProduct = {
//     id: products1.length > 0 ? products1[products1.length - 1].id + 1 : 1,
//     title: elFormAdd.title.value,
//     img: imageSrc,
//     real_price: elFormAdd.real_price.value,
//     discount_price: elFormAdd.discount_price.value,
//     monthly_payment: elFormAdd.monthly.value,
//     isLiked: false,
//     reting: "4",
//   };

//   products1.push(newProduct);

//   localStorage.setItem("products1", JSON.stringify(products1));
//   renderProducts();
// });

elWrapperProducts.addEventListener("click", (evt) => {
  // if (evt.target.className.includes("btn-yurak")) {
  //   const id = Number(evt.target.dataset.id);

  //   products1.forEach((product) => {
  //     if (product.id === id) {
  //       product.isLiked = !product.isLiked;
  //     }
  //   });

  //   localStorage.setItem("products1", JSON.stringify(products1));
  //   renderProducts();
  // }
  if (evt.target.className.includes("mahsulot")) {
    const id = evt.target.dataset.id;
    localStorage.setItem("id", id);
    window.location.replace(`http://127.0.0.1:5500/single-page.html?id=${id}`);
  }
});

const elInput = findElement("#search-input");
elInput.addEventListener("input", () => {
  const value = elInput.value.toLowerCase();
  const elWrapperDiv = document.querySelectorAll(".arzon__div");

  elWrapperDiv.forEach((product) => {
    const title =
      product.lastElementChild.children[0].textContent.toLowerCase();

    console.log(product.lastElementChild.children[0].textContent);

    if (title.includes(value)) {
      product.classList.remove("hidden");
    } else {
      product.classList.add("hidden");
    }
  });
});
