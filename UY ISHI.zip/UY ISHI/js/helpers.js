export const findElement = (element, parent = document) => {
  return parent.querySelector(element);
};
