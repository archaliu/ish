function outer() {
    function create_Closure(val) {
        return function () {
            return val;
        };
    }
    var arr = [];
    var i;
    for (i = 0; i < 4; i++) {
        arr[i] = create_Closure(i);
    }
    return arr;
}
// function pure bir xil argumentda bir xil qiymat qaytaradi (tashqi tasirlar ta'sir qilmasligi kerak)
// factory function - funksiya yangi obyekt yaratib qaytarsa
// recursion - funksiya o'zini ichida o'zi chaqirsa rekursiv f-ya d-di
// callback - funksiyaning parametrida kelgan funksiyaga aytiladi
// hof -   funksiyaning parametrida funksiya kelsa  (callback f-ya kelsa)
// iife -e'lon qilingan zahoti chaqirilgan funksiya
